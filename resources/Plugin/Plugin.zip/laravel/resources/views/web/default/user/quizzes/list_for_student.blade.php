@extends($user['vendor'] == 1 ? getTemplate() . '.user.layout.videolayout' : getTemplate() . '.user.layout_user.videolayout')
@section('tab1','active')
@section('tab')
    <div class="h-20"></div>
    <div class="off-filters-li">

    </div>
@endsection
